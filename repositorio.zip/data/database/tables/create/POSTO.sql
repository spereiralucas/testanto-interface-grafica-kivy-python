CREATE TABLE IF NOT EXISTS POSTO (
	idPosto INT auto_increment,
	nomePosto VARCHAR (45),
	enderecoPosto VARCHAR (45),
	PRIMARY KEY (idPosto)
);