INSERT INTO POSTO
	(idPosto, nomePosto, enderecoPosto)
VALUES
	(1, "Canoa", "Av. Copacabana - Atibaia"),
	(2, "Pedra Grande", "Av. Carvalho Pinto - Atibaia"),
	(3, "Tiger", "Praça do Rosario - Atibaia"),
	(4, "Graal", "Rodovia Dom Pedro I - Jarinu"),
	(5, "Europa", "Av. Imigrantes - Bragança"),
	(6, "Tasca", "Av. Pires Pimentel - Bragança");