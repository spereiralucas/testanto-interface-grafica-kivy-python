INSERT INTO BOMBA
	(idBomba, tipo, preco, idPosto)
VALUES
	(null, "Gasolina", 4.49, 10),
	(null, "Etanol", 2.89, 11),
	(null, "Diesel", 3.79, 12);