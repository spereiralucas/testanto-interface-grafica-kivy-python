INSERT INTO CLIENTE 
	(nomeCliente, endereco, CPF)
VALUES
	("Lucas Pereira", "Av. Sto. Antonio, 69", 41912348896),
	("Jefferson Castro", "Av. Sete de Setembro, 81", 12345678910),
	("Luiz Felipe", "Av. Juca Peçanha", 45945612399),
	("Jailson Mendes", "Travessa Jaçanã s/n", 44129403111),
	("Paulo Guina", "Rua Mangueira, 24", 32383687114),
	("Kauã Desu", "Sitio Trilha - Peça", 55529657822),
	("Marcos Paulo Oliveira", "Rua Primeiro de Maio, 448", 45688896301),
	("Flavia Matias", "Rua das Olimpiadas, 100", 12045898766),
	("Adriana Matarazo", "Rua José de Alencar, 1268", 65812347887),
	("Ana Maria Silva", "Rua Padre José de Anchieta, 788", 71478955630);