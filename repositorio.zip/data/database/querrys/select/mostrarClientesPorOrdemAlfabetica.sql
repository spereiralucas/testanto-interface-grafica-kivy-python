SELECT * FROM CLIENTE
group by nomeCliente;