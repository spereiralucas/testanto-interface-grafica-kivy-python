from src.view.gui import Gui

Gui().run()
